"""
Scenario Execution & Plot Generation Script.

Author: Shyambaskar Sriram
SASTRA University - B.E. Computer Science & Engineering (AI & DS)

Description:
    Runs closed-loop simulations for Honeywell Round 2 demonstration scenarios:
        - Scenario A: Startup to Target (Target = 110 bbl/hr)
        - Scenario B: Target Tracking (100 -> 150 bbl/hr)
        - Scenario C: Infeasible Target (Target = 220 bbl/hr)
    Generates publication-ready 5-panel trend plots for each scenario.
"""

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os

from simulator import OilWellSimulator
from mpc_controller import AutonomousChokeController


def run_simulation(scenario_name, target_profile, timesteps=50, initial_choke=30.0):
    """
    Executes closed-loop simulation over the specified time horizon.
    
    Parameters:
        scenario_name (str): Label for the scenario.
        target_profile (list): Array of target oil flow rates per hour step.
        timesteps (int): Total simulation horizon in hours (default: 50).
        initial_choke (float): Initial choke opening percentage (default: 30.0%).
        
    Returns:
        tuple: (DataFrame of telemetry history, List of candidate move rejection logs)
    """
    # Instantiate simulator environment and autonomous controller
    sim = OilWellSimulator(initial_choke=initial_choke, seed=42)
    controller = AutonomousChokeController(whp_min=210.0, flp_min=150.0, bhp_min=2850.0, max_ramp=5.0)
    
    # Initialize telemetry recording dictionary
    history = {
        'Time_hr': [],
        'Target_Q': [],
        'Actual_Q': [],
        'WHP': [],
        'FLP': [],
        'BHP': [],
        'Choke_pct': []
    }
    
    current_u = initial_choke
    current_state = {'Q': sim.Q, 'WHP': sim.WHP, 'FLP': sim.FLP, 'BHP': sim.BHP}
    
    # Run hourly control loop
    for t in range(timesteps):
        # Fetch setpoint target for current hour step
        target_q = target_profile[t] if t < len(target_profile) else target_profile[-1]
        
        # Step 1: Compute optimal safe choke move using MPC controller
        next_u = controller.compute_next_choke_position(current_u, target_q, current_state)
        
        # Step 2: Pass choke command to simulator (matching Q, WHP, FLP, BHP = simulator.step(u))
        actual_q, whp, flp, bhp = sim.step(next_u)
        next_state = {'Q': actual_q, 'WHP': whp, 'FLP': flp, 'BHP': bhp}
        
        # Step 3: Trigger live online gain learning update
        controller.update_model(current_u, next_u, current_state, next_state)
        
        # Step 4: Advance state pointers
        current_u = next_u
        current_state = next_state
        
        # Record hourly process telemetry
        history['Time_hr'].append(t)
        history['Target_Q'].append(target_q)
        history['Actual_Q'].append(actual_q)
        history['WHP'].append(whp)
        history['FLP'].append(flp)
        history['BHP'].append(bhp)
        history['Choke_pct'].append(current_u)
        
    df_res = pd.DataFrame(history)
    return df_res, controller.rejection_log


def plot_scenario_results(df_res, scenario_title, filename):
    """
    Generates a 5-panel trend plot matching Honeywell's presentation requirements.
    
    Panels:
        1. Target Oil Rate vs Actual Oil Rate (bbl/hr)
        2. Wellhead Pressure (WHP in psi) with safety threshold
        3. Flowline Pressure (FLP in psi) with safety threshold
        4. Bottom Hole Pressure (BHP in psi) with safety threshold
        5. Choke Position opening (%)
    """
    fig, axes = plt.subplots(5, 1, figsize=(10, 12), sharex=True)
    fig.suptitle(f"Autonomous Choke Control Performance — {scenario_title}", fontsize=13, fontweight='bold')
    
    # Panel 1: Oil Flow Rate Tracking
    axes[0].plot(df_res['Time_hr'], df_res['Target_Q'], 'r--', linewidth=1.8, label='Target Q (bbl/hr)')
    axes[0].plot(df_res['Time_hr'], df_res['Actual_Q'], 'b-', linewidth=1.8, label='Actual Q (bbl/hr)')
    axes[0].set_ylabel("Oil Rate\n(bbl/hr)")
    axes[0].grid(True, linestyle='--', alpha=0.5)
    axes[0].legend(loc='upper right')
    
    # Panel 2: Wellhead Pressure (WHP) Safety Limits
    axes[1].plot(df_res['Time_hr'], df_res['WHP'], 'g-', linewidth=1.8, label='WHP (psi)')
    axes[1].axhline(y=210.0, color='r', linestyle=':', linewidth=1.8, label='WHP Limit (210 psi)')
    axes[1].set_ylabel("WHP\n(psi)")
    axes[1].grid(True, linestyle='--', alpha=0.5)
    axes[1].legend(loc='upper right')
    
    # Panel 3: Flowline Pressure (FLP) Safety Limits
    axes[2].plot(df_res['Time_hr'], df_res['FLP'], 'm-', linewidth=1.8, label='FLP (psi)')
    axes[2].axhline(y=150.0, color='r', linestyle=':', linewidth=1.8, label='FLP Limit (150 psi)')
    axes[2].set_ylabel("FLP\n(psi)")
    axes[2].grid(True, linestyle='--', alpha=0.5)
    axes[2].legend(loc='upper right')
    
    # Panel 4: Bottom Hole Pressure (BHP) Safety Limits
    axes[3].plot(df_res['Time_hr'], df_res['BHP'], 'c-', linewidth=1.8, label='BHP (psi)')
    axes[3].axhline(y=2850.0, color='r', linestyle=':', linewidth=1.8, label='BHP Limit (2850 psi)')
    axes[3].set_ylabel("BHP\n(psi)")
    axes[3].grid(True, linestyle='--', alpha=0.5)
    axes[3].legend(loc='upper right')
    
    # Panel 5: Choke Valve Position (%)
    axes[4].plot(df_res['Time_hr'], df_res['Choke_pct'], 'k-', linewidth=1.8, label='Choke Opening (%)')
    axes[4].set_ylabel("Choke Position\n(%)")
    axes[4].set_xlabel("Time (Hours)")
    axes[4].grid(True, linestyle='--', alpha=0.5)
    axes[4].legend(loc='upper right')
    
    # Layout adjustment and plot export
    plt.tight_layout(rect=[0, 0.03, 1, 0.96])
    plt.savefig(filename, dpi=300)
    plt.close()
    print(f"Generated plot: {filename}")


def main():
    """
    Main driver script executing all three demonstration scenarios.
    """
    print("=== Running Scenario Demonstrations ===")
    output_dir = r"c:\Honeywell Project\Code"
    
    # Scenario A: Startup to Target (110 bbl/hr)
    target_A = [110.0] * 50
    df_A, rejections_A = run_simulation("Scenario A", target_A, timesteps=50, initial_choke=30.0)
    plot_scenario_results(df_A, "Scenario A: Startup to Target (110 bbl/hr)", os.path.join(output_dir, "scenario_A_results.png"))
    
    # Scenario B: Target Tracking (100 -> 150 bbl/hr at t=25)
    target_B = [100.0] * 25 + [150.0] * 25
    df_B, rejections_B = run_simulation("Scenario B", target_B, timesteps=50, initial_choke=35.0)
    plot_scenario_results(df_B, "Scenario B: Target Tracking (100 -> 150 bbl/hr)", os.path.join(output_dir, "scenario_B_results.png"))
    
    # Scenario C: Infeasible Target (220 bbl/hr)
    target_C = [220.0] * 50
    df_C, rejections_C = run_simulation("Scenario C", target_C, timesteps=50, initial_choke=30.0)
    plot_scenario_results(df_C, "Scenario C: Infeasible Target (Safe Envelope Settling)", os.path.join(output_dir, "scenario_C_results.png"))
    
    # Print numerical summary metrics
    print("\n--- Execution Summary ---")
    print(f"Scenario A Final Flow: {df_A['Actual_Q'].iloc[-1]:.2f} bbl/hr | Min WHP: {df_A['WHP'].min():.2f} psi | Rejections: {len(rejections_A)}")
    print(f"Scenario B Final Flow: {df_B['Actual_Q'].iloc[-1]:.2f} bbl/hr | Min WHP: {df_B['WHP'].min():.2f} psi | Rejections: {len(rejections_B)}")
    print(f"Scenario C Settled Flow: {df_C['Actual_Q'].iloc[-1]:.2f} bbl/hr | Min WHP: {df_C['WHP'].min():.2f} psi | Rejections: {len(rejections_C)}")


if __name__ == "__main__":
    main()
