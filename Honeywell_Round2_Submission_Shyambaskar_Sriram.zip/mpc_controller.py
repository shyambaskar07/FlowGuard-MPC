"""
Autonomous Model Predictive Controller (MPC) for Oil Well Choke Control.

Author: Shyambaskar Sriram
SASTRA University - B.E. Computer Science & Engineering (AI & DS)

Description:
    Implements a multi-step Receding Horizon Model Predictive Controller (MPC)
    with adaptive telemetry noise filtering, online system identification,
    deadband chatter prevention, and a Candidate Move Rejection Engine.
"""

import numpy as np


class AdaptiveTelemetryFilter:
    """
    Adaptive Exponential Noise Filter.
    Smoothes raw process telemetry (Q, WHP, FLP, BHP) to eliminate measurement noise spikes.
    """
    def __init__(self, alpha=0.3):
        self.alpha = alpha
        self.filtered_state = None
        
    def filter(self, raw_state):
        if self.filtered_state is None:
            self.filtered_state = dict(raw_state)
        else:
            for key in ['Q', 'WHP', 'FLP', 'BHP']:
                if key in raw_state:
                    self.filtered_state[key] = (1 - self.alpha) * self.filtered_state[key] + self.alpha * raw_state[key]
        return dict(self.filtered_state)


class OnlineSystemID:
    """
    Online Recursive System Identification Engine.
    Dynamically estimates process gains (dQ/du, dWHP/du, dFLP/du, dBHP/du) online.
    """
    def __init__(self):
        self.gain_Q = 1.83     # Oil flow rate gain (bbl/hr per % choke)
        self.gain_WHP = -1.42  # Wellhead Pressure gain (psi per % choke)
        self.gain_FLP = -0.94  # Flowline Pressure gain (psi per % choke)
        self.gain_BHP = -6.40  # Bottom Hole Pressure gain (psi per % choke)
        
    def update(self, u_prev, u_curr, state_prev, state_curr):
        du = u_curr - u_prev
        if abs(du) > 0.1:
            dQ = state_curr['Q'] - state_prev['Q']
            dWHP = state_curr['WHP'] - state_prev['WHP']
            dFLP = state_curr['FLP'] - state_prev['FLP']
            dBHP = state_curr['BHP'] - state_prev['BHP']
            
            lr = 0.2
            self.gain_Q = max(0.1, (1 - lr) * self.gain_Q + lr * (dQ / du))
            self.gain_WHP = min(-0.1, (1 - lr) * self.gain_WHP + lr * (dWHP / du))
            self.gain_FLP = min(-0.1, (1 - lr) * self.gain_FLP + lr * (dFLP / du))
            self.gain_BHP = min(-0.1, (1 - lr) * self.gain_BHP + lr * (dBHP / du))

    def predict_horizon(self, u_curr, candidate_du_sequence, state_curr):
        """
        Predicts process state trajectories over a multi-step horizon sequence.
        """
        trajectory = []
        sim_u = u_curr
        sim_state = dict(state_curr)
        
        for du in candidate_du_sequence:
            sim_u += du
            sim_state = {
                'Q': sim_state['Q'] + self.gain_Q * du,
                'WHP': sim_state['WHP'] + self.gain_WHP * du,
                'FLP': sim_state['FLP'] + self.gain_FLP * du,
                'BHP': sim_state['BHP'] + self.gain_BHP * du,
                'u': sim_u
            }
            trajectory.append(sim_state)
            
        return trajectory


class AutonomousChokeController:
    """
    Multi-Step Receding Horizon Model Predictive Controller (MPC).
    Strictly enforces active safety limits, hard ramp constraints, and candidate rejection.
    """
    def __init__(self, whp_min=210.0, flp_min=150.0, bhp_min=2850.0, max_ramp=5.0, horizon=3):
        """
        Parameters:
            whp_min (float): Minimum WHP limit in psi (default: 210.0).
            flp_min (float): Minimum FLP limit in psi (default: 150.0).
            bhp_min (float): Minimum BHP limit in psi (default: 2850.0).
            max_ramp (float): Max choke ramp rate per step in % (default: 5.0).
            horizon (int): Multi-step prediction horizon Np (default: 3 steps).
        """
        self.whp_min = float(whp_min)
        self.flp_min = float(flp_min)
        self.bhp_min = float(bhp_min)
        self.max_ramp = float(max_ramp)
        self.horizon = int(horizon)
        
        # Deadband threshold to eliminate choke chatter when error is negligible
        self.deadband_q = 0.15 # bbl/hr
        
        self.telemetry_filter = AdaptiveTelemetryFilter(alpha=0.3)
        self.online_id = OnlineSystemID()
        self.rejection_log = []

    def validate_trajectory(self, u_curr, candidate_du, state_curr):
        """
        Evaluates a candidate move over the prediction horizon.
        Rejects moves that breach ramp rates or pressure safety limits.
        """
        # 1. Ramp rate constraint check (|du| <= 5%)
        if abs(candidate_du) > self.max_ramp + 1e-5:
            return False, f"Ramp limit exceeded: |{candidate_du:.2f}%| > {self.max_ramp}%", None
            
        candidate_u = u_curr + candidate_du
        if candidate_u < 0.0 or candidate_u > 100.0:
            return False, f"Choke bounds breached: {candidate_u:.2f}%", None
            
        # Predict multi-step trajectory
        du_sequence = [candidate_du] + [0.0] * (self.horizon - 1)
        trajectory = self.online_id.predict_horizon(u_curr, du_sequence, state_curr)
        
        # Check active pressure limits across all steps in prediction horizon
        for step_idx, pred_state in enumerate(trajectory):
            if pred_state['WHP'] < self.whp_min:
                return False, f"WHP breach at step +{step_idx+1}: {pred_state['WHP']:.2f} psi < {self.whp_min} psi", pred_state
            if pred_state['FLP'] < self.flp_min:
                return False, f"FLP breach at step +{step_idx+1}: {pred_state['FLP']:.2f} psi < {self.flp_min} psi", pred_state
            if pred_state['BHP'] < self.bhp_min:
                return False, f"BHP breach at step +{step_idx+1}: {pred_state['BHP']:.2f} psi < {self.bhp_min} psi", pred_state
                
        return True, None, trajectory[0]

    def compute_next_choke_position(self, u_curr, target_Q, current_state):
        """
        Computes the optimal choke position for the next 1-hour control step.
        """
        # Filter raw process telemetry
        filtered_state = self.telemetry_filter.filter(current_state)
        
        # Deadband check: if actual flow rate is within deadband threshold of target, hold choke position
        q_error = abs(filtered_state['Q'] - target_Q)
        if q_error <= self.deadband_q:
            # Validate holding current position
            is_valid, _, _ = self.validate_trajectory(u_curr, 0.0, filtered_state)
            if is_valid:
                return u_curr

        # Grid search over candidate choke moves in allowable ramp range [-5%, +5%]
        candidate_dus = np.linspace(-self.max_ramp, self.max_ramp, 101)
        
        best_u = u_curr
        best_cost = float('inf')
        max_safe_q = -float('inf')
        max_safe_u = u_curr
        
        for du in candidate_dus:
            candidate_u = u_curr + du
            is_valid, reason, pred_1step = self.validate_trajectory(u_curr, du, filtered_state)
            
            if not is_valid:
                self.rejection_log.append({
                    'u_curr': u_curr,
                    'candidate_u': candidate_u,
                    'reason': reason
                })
                continue
                
            # Track maximum safe oil production rate for infeasible targets (Scenario C requirement)
            if pred_1step['Q'] > max_safe_q:
                max_safe_q = pred_1step['Q']
                max_safe_u = candidate_u
                
            # Quadratic cost: setpoint error squared + control effort penalty
            w_effort = 0.5
            cost = (pred_1step['Q'] - target_Q)**2 + w_effort * (du**2)
            
            if cost < best_cost:
                best_cost = cost
                best_u = candidate_u
                
        # Handle infeasible target fallback (Page 3 requirement: settle at max safe production)
        if target_Q > max_safe_q and best_cost > 100.0:
            return max_safe_u

        return best_u

    def update_model(self, u_prev, u_curr, state_prev, state_curr):
        """Updates internal model gains after executing a control step."""
        filtered_prev = self.telemetry_filter.filter(state_prev)
        filtered_curr = self.telemetry_filter.filter(state_curr)
        self.online_id.update(u_prev, u_curr, filtered_prev, filtered_curr)
